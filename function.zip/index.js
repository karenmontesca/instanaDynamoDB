const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

const client = new DynamoDBClient({});

exports.handler = async (event) => {
  const params = {
    TableName: "UsuariosPOC",
    Item: {
      userId: { S: "user-" + Date.now() },
      timestamp: { S: new Date().toISOString() }
    },
  };

  try {
    await client.send(new PutItemCommand(params));
    console.log("Dato insertado con éxito.");
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Dato guardado correctamente." }),
    };
  } catch (err) {
    console.error("Error al insertar:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error al guardar." }),
    };
  }
};
